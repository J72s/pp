///////////////////////////
///
// Importing the config.js file
const token = require('./config.js').token;

// Output the token to ensure it's retrieved correctly
console.log("Token from config.js:", token);

module.exports = {
    showTime: false, // Toggle to show or hide time in status (true/false)
    token: token,
    timeZone: "Asia/Kolkata", //Your Timezone, eg Asia/Kolkata
    Name: "Eric",
    State: "Just shut up",
    Details: "ُُEric",
    FirstButtonName: "My Server",
    FirstButtonUrl: "https://discord.gg/KGnvcT5A8V",
    LargeImage: "https://i.pinimg.com/236x/3a/bc/58/3abc583bed2b304c1b67666fbeb2019e.jpg", // DISCORD CDN IMAGE ONLY
    LargeText: "Eric", // hover text for large image
    SmallImage: "https://i.pinimg.com/236x/3a/bc/58/3abc583bed2b304c1b67666fbeb2019e.jpg", // DISCORD CDN IMAGE ONLY
    SmallText: "...", // hover text for small image
  };
  